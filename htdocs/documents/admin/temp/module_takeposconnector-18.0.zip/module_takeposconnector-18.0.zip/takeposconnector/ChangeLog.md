# CHANGELOG TAKEPOSCONNECTOR FOR [DOLIBARR ERP CRM](https://www.dolibarr.org)

##

Current version
